﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1.Forms
{
    public partial class frmConsAgenda : Form
    {
        banco bd = new banco();
        string sql;
        MySqlCommand cmd;

        public frmConsAgenda()
        {
            InitializeComponent();
            busca();
            
        }


        //-----------------------------------------------------crud do form----------------------------------------------------------

        //buscar
        private void btnSelect_Click(object sender, EventArgs e)
        {
            bd.abrirConn();
            sql = "SELECT Agendamento.Id as ID, Cliente.NOME AS Cliente, Servico.NOME AS Serviço, Agendamento.DATA_AGENDAMENTO as Data, Agendamento.HORA_AGENDAMENTO as Hora, Funcionario.NOME AS Funcionário, Servico.PRECO as Preço " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id " +
                  "WHERE Agendamento.DATA_AGENDAMENTO = @DataAgenda";

            cmd = new MySqlCommand(sql, bd.conecta);
            cmd.Parameters.AddWithValue("@DataAgenda", dtBusca.Value);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
            
        }

        
        //atualizar dados
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Tem certeza que deseja alterar os dados?", "Dados atualizados!", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                bd.abrirConn();

                sql = @"UPDATE agendamento
        SET agendamento.FUNCIONARIO_ID = (SELECT f.ID FROM funcionario f WHERE f.nome = @Func),
            agendamento.FK_CLIENTE_ID = (SELECT c.ID FROM cliente c WHERE c.nome = @Cliente),
            agendamento.FK_SERVICO_ID = (SELECT s.ID FROM servico s WHERE s.nome = @Serv),
            agendamento.DATA_AGENDAMENTO = @DataAgenda,
            agendamento.HORA_AGENDAMENTO = @HoraAgenda
        WHERE agendamento.ID = @Id";

                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@Func", cbFunc.Text);
                cmd.Parameters.AddWithValue("@Cliente", tbCliente.Text);
                cmd.Parameters.AddWithValue("@Serv", cbServico.Text);
                cmd.Parameters.AddWithValue("@DataAgenda", dtAgendamento.Value);
                cmd.Parameters.AddWithValue("@HoraAgenda", dtHora.Value);
                cmd.Parameters.AddWithValue("@Id", tbId.Text);
                cmd.ExecuteNonQuery();
                
                
            }

        }


        //deletar
        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Tem certeza que deseja excluir os dados ?", "Dados excluídos!", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                bd.abrirConn();
                sql = "Delete from agendamento where id=@id";
                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@id", tbId.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Dados deletados!");
               
            }
        }

        //reseta o datagridview, voltando a mostrar todos os agendamentos (caso tenha apertado o "buscar" e queira voltar atrás)
        private void btnReset_Click(object sender, EventArgs e)
        {
            busca();
            FillFuncionario();
            FillServico();
        }

        //---------------------------------------------informações do agendamento nos textbox----------------------------------------

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                string id = row.Cells["ID"].Value.ToString();
                tbId.Text = id;

                string data = row.Cells["Data"].Value.ToString();
                dtAgendamento.Value = DateTime.Parse(data);

                string hora = row.Cells["Hora"].Value.ToString();
                dtHora.Value = DateTime.Today.Add(TimeSpan.Parse(hora));

                string servico = row.Cells["SERVIÇO"].Value.ToString();
                cbServico.Enabled = true;
                cbServico.SelectedItem = servico;

                string funcionario = row.Cells["FUNCIONÁRIO"].Value.ToString();
                cbFunc.Enabled = true;
                cbFunc.SelectedItem = funcionario;

                string cliente = row.Cells["CLIENTE"].Value.ToString();
                tbCliente.ReadOnly = false;
                tbCliente.Text = cliente;

                string valor = row.Cells["PREÇO"].Value.ToString();
                tbValor.ReadOnly = false;
                tbValor.Text = valor;

                FillFuncionario();
                FillServico();
        }

        //------------------------------------------------------------funções---------------------------------------------------------
        private void busca()
        {
            bd.abrirConn();
            sql = "SELECT Agendamento.ID as ID, Cliente.NOME AS Cliente, Servico.NOME AS Serviço, Agendamento.DATA_AGENDAMENTO as Data, Agendamento.HORA_AGENDAMENTO as Hora, Funcionario.NOME AS Funcionário, Servico.PRECO as Preço " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id ";

            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }
 


        private void FillFuncionario()
        {
            bd.abrirConn();
            sql = "select nome from funcionario";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbFunc.DataSource = dt;
                cbFunc.DisplayMember = "nome";
            }

        }
        private void FillServico()
        {
            bd.abrirConn();
            sql = "select nome from servico";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbServico.DataSource = dt;
                cbServico.DisplayMember = "nome";
            }
        }
        //------------------------------------------parte inútil só para o form não bugar--------------------------------------------

        private void dtBusca_ValueChanged(object sender, EventArgs e)
        {

        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {

        }

        private void cbServico_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmConsAgenda_Load(object sender, EventArgs e)
        {

        }

        private void cbFunc_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbCliente_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        
    }
}